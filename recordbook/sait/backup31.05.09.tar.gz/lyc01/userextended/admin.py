# -*- coding: UTF-8 -*-

from django.contrib import admin
from lyc01.userextended.models import Grade, Subject, Connection, ExtendedUser

class GradeAdmin(admin.ModelAdmin):
    list_display = ('long_name',)

class SubjectAdmin(admin.ModelAdmin):
    list_display = ('name',)

class ConnectionAdmin(admin.ModelAdmin):
    list_display = ('grade', 'subject', 'teacher')

class ExtendedUserAdmin(admin.ModelAdmin):
    def fio(obj):
        return obj.last_name+' '+obj.first_name+' '+obj.middle_name
    fio.short_description = u'Фамилия, имя, отчество'
    list_display = (fio, 'group')
    fieldsets = [
                 (u'Имя', {'fields': ['last_name', 'first_name', 'middle_name']}),
                 (u'Права', {'fields': ['group', 'grade']})
                ]
    radio_fields = {'group': admin.HORIZONTAL}
    search_fields = ['first_name', 'last_name']
    list_filter = ('group',)
    
admin.site.register(Grade, GradeAdmin)
admin.site.register(Subject, SubjectAdmin)
admin.site.register(Connection, ConnectionAdmin)
admin.site.register(ExtendedUser, ExtendedUserAdmin)