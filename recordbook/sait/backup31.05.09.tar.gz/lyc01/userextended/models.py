# -*- coding: UTF-8 -*-

from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
import pytils

class Grade(models.Model):
    u"Класс"
    long_name = models.CharField(u"Длинное имя", max_length = 100)
    small_name = models.CharField(u"Короткое имя", max_length = 10)
    def __unicode__(self):
        return self.long_name

class Connection(models.Model):
    grade = models.ForeignKey('userextended.Grade')
    group = models.IntegerField(u'Группа')
    teacher = models.ForeignKey('userextended.ExtendedUser')
    subject =  models.ForeignKey('userextended.Subject')

class Subject(models.Model):
    name = models.CharField(u"Предмет", max_length = 100)
    teachers = models.ManyToManyField('userextended.ExtendedUser', verbose_name="Учителя")

class ExtendedUser(User):
    last_name = models.CharField(u"Фамилия", max_length = 30)
    first_name = models.CharField(u"Имя", max_length = 30)
    middle_name = models.CharField(u"Отчество", max_length = 30)
    group = models.ForeignKey('auth.Group', verbose_name="Группа")
    password_journal = models.CharField(u"Пароль доступа к дневнику", max_length = 255)
    grade = models.ForeignKey('userextended.Grade', verbose_name="Класс", blank = True)
    def save(self, force_insert=False, force_update=False):
        if self.group.name == u"Ученик":
            username = "p."
        if self.group.name == u"Учитель":
            username = "t."
        last_name = pytils.translit.exttranslify(self.last_name.lower())
        first_name = pytils.translit.exttranslify(self.first_name.lower())
        if len(last_name)+len(first_name)>28:
            if len(last_name)>25:
                last_name = last_name[:25]
                first_name = first_name[:3]
            else:
                if len(last_name)>len(first_name):
                    last_name = last_name[:28-len(first_name)]
                else:
                    first_name = first_name[:28-len(first_name)]
        self.username = username + last_name + '.' + first_name
        super(ExtendedUser, self).save(force_insert, force_update)
    def __unicode__(self):
        result = self.last_name + ' ' + self.first_name + ' ' + self.middle_name
        if self.grade:
            result = result + ' (' + self.grade.small_name + ')'
        return result
    
#    grade_manager = models.BooleanField(u"Классный руководитель")
    